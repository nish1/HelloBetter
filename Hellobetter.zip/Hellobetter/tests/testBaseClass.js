'use strict';
const regPage = require('../classes/pages/regPage.js');
const regpage = new regPage();
const loginPage = require('../classes/pages/loginPage.js');
const loginpage = new loginPage();
const journalPage = require('../classes/pages/journalPage.js');
const journalpage = new journalPage();
const journalPage2 = require('../classes/pages/journalPage2.js');
const journalpage2 = new journalPage2();
const morningPage = require('../classes/pages/morningPage.js');
const morningpage = new morningPage();


class testBaseClass {
    constructor() {
       this.regpage=regpage;
        this.loginpage = loginpage;
        this.journalpage = journalpage;
        this.journalpage2=journalpage2;
        this.morningpage=morningpage;
      

    }
}

module.exports = testBaseClass;
