'use strict';


const testBaseClass = require('../tests/testBaseClass.js');
const testBase = new testBaseClass();

describe('Testing - HelloBetter', function () {
  var originalTimeout;

  beforeEach(function () {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  afterEach(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });


  it('should open the Login Page', function () {
    testBase.loginpage.openPage();
  });

 it('should login to the Portal', function () {
    testBase.loginpage.loginPortal();
  });


  it('should search the Portal for Journal entries and navigate diary entry', function () {

    testBase.journalpage.journalPortal();

  });
  it('should enter the morning entry  in the journal and save the diary entry', function () {

    testBase.journalpage.morningEntry();

  });
  it('should search the Portal for Journal entries and navigate diary entry', function () {

    testBase.journalpage.journalPortal();

  });
  it('should enter the evening entry  in the journal and save the diary entry', function () {

    testBase.journalpage.eveningEntry();

  });

  it('should validate  the morning entries on different dates on Chart', function () {
    testBase.morningpage.morningPortal();

  });
  it('should validate  the evening entries on different dates on Chart', function () {
    testBase.morningpage.eveningPortal();

  });
  it('should validate  Time spent in Bed on different dates on Chart', function () {
    testBase.morningpage.eveningPortal();

  });

  it('should validate  the evening entries on different dates on Chart and Logout', function(){
   testBase.morningpage.logoutPortal();

  });

 /*it('should validate  Registration and change the portal language ', function(){
   testBase.regpage.regPortal();

  });  */




});
