const { element } = require("protractor");

class journalPageLocator {
    constructor() {
        //this.searchTitle = 'Search - windows';
      // this.dateEntry=element(by.className('Anchor__StyledAnchor-sc-8ebe3y-0 Veymb'));
      //this.previousMonth=element(by.className('react-datepicker__navigation react-datepicker__navigation--previous'));
      // this.dateField = element(by.className('react-datepicker__day react-datepicker__day--026 react-datepicker__day--selected'));
       this.nextEntry = element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn'));
       this.entryTime=element(by.className('components__Input-sc-1wuj3q6-5 kBbBKB'));

       this.eveningEntry=element(by.className('Button__Component-sc-1cra7sq-0 lerbpD'));
       this.nextEntry = element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn'));
    this.slider=element(by.className('MuiSlider-mark MuiSlider-markActive'));
    this.continueEntry=element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn'));
    this.exhuastEntry=element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn'));
    this.sleepTime=element(by.className('components__Input-sc-1wuj3q6-5 kBbBKB'));
    this.coffeeEntry=element(by.xpath('//*[@id="main"]/div/div[2]/div/div/div[1]/div/div/div[2]/div[1]/div[2]/div/button[2]'));
    this.teaEntry=element(by.xpath('//*[@id="main"]/div/div[2]/div/div/div[1]/div/div/div[2]/div[2]/div[2]/div/button[2]'));
    this.colaEntry=element(by.xpath('//*[@id="main"]/div/div[2]/div/div/div[1]/div/div/div[2]/div[4]/div[2]/div/button[2]'));
    this.beerEntry=element(by.xpath('//*[@id="main"]/div/div[2]/div/div/div[1]/div/div/div[2]/div[1]/div[2]/div/button[2]'));
       
        //this.addtoCart = element.all(by.xpath('//span[contains(text(), "Add to Cart")]')).get(0);
        //this.sucsessMsg = element(by.xpath('//div[@class="alert alert-success alert-dismissible"]'));
    }
}

module.exports = journalPageLocator;