const { element } = require("protractor");

class morningPageLocator {
constructor() {
this.morningEntryTitle='HelloBetter';

//this.morningEntry2=element(by.xpath('//*[@id="journal_entry_container_3"]/div/div[1]/div/p'));
this.timeBed=element(by.className('Headline-p8v9lo-0 mSrUP'));
//this.entry19=element(by.className('Button__Component-sc-1cra7sq-0 lapbsY'));
this.saveEntry=element(by.buttonText('Save'));
this.leftEntry=element(by.className('Button__Component-sc-1cra7sq-0 ktuSAX'));
this.logout = element(by.className('components__Icon-vq0nuj-6 eftjTR'));
}
}

module.exports = morningPageLocator;