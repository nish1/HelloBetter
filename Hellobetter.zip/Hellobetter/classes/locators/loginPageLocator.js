class loginPageLocator {
    constructor() {
        this.loginTitle = 'HelloBetter';
        this.postLoginTitle = 'HelloBetter';
        this.logoutTitle = 'HelloBetter';

    

        this.emailField = element(by.css('#email'));
       this.passwordField = element(by.css('#password'));
       this.loginButton = element(by.buttonText('Einloggen'));
       //this.journalEntry = element(by.className('components__Path-vq0nuj-0 cSyhSj'));
       this.logout = element(by.className('components__Icon-vq0nuj-6 eftjTR'));
        
    }
}

module.exports = loginPageLocator;