const { element } = require("protractor");

class regLocator {
    constructor() {



        this.register = element(by.className('Anchor__StyledAnchor-sc-8ebe3y-0 Veymb'));
        this.firstName = element(by.css('#firstName'));

        this.emailField = element(by.css('#email'));
        this.passwordField = element(by.css('#password'));
        this.Training = element(by.className('components__StyledSelect-sc-1ssyjqu-1 ewOvUT'));
        this.check = element(by.className('components__Rect-vq0nuj-3 eSviAj'));
        this.languageSwap = element(by.className('Button__Component-sc-1cra7sq-0 czuyAY ChangeLanguage__ButtonLink-sc-18kdjhg-0 SwwaP'));
        this.english = element(by.className('components__ListItemStyled-eczaep-1 hvPSzP'));
        this.register = element(by.className('Button__Component-sc-1cra7sq-0 dqgmrB'));

    }
}

module.exports = regLocator;