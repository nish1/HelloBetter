'use strict';
const { browser } = require('protractor');
const journalPageLocator = require('../locators/journalPageLocator.js');

class journalPage2 {
  constructor() {
    this.locator = new journalPageLocator();
    this.bedtime = browser.params.login.bedtime;
    this.EC = protractor.ExpectedConditions;
    this.timeOut = 60000;
  }

  journalPortal() {
    browser.ignoreSynchronization = true
    browser.sleep(4000)
    browser.driver.actions().mouseMove(element(by.className('Anchor__StyledAnchor-sc-8ebe3y-0 Veymb')).getWebElement()).perform();
    return browser.actions().click().perform();
    // this.locator.serachIcon.click();
    //  expect(browser.getTitle()).toEqual(this.locator.searchTitle);
  }

  morningEntry(){
  browser.ignoreSynchronization = true
 
  browser.sleep(3000)
  expect(browser.getTitle()).toEqual('HelloBetter');
   browser.driver.actions().mouseMove(element(by.className('Anchor__StyledAnchor-sc-8ebe3y-0 Veymb')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('react-datepicker__day react-datepicker__day--003 react-datepicker__day--selected react-datepicker__day--weekend')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Box__StyledBox-vxlplq-0 fNLFjo TimeInput__Container-sc-1jrs8fz-0 cEPoXF')).getWebElement(0)).click().perform();
  browser.actions().sendKeys('21:00').perform(); 
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 iCfpHO')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  element(by.cssContainingText('option','3')).click();
  this.locator.entryTime.sendKeys('7');
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.driver.actions().mouseMove(element(by.className('components__Input-sc-1wuj3q6-5 kBbBKB')).getWebElement()).click().perform();
  browser.actions().sendKeys('Woke up in between').perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  browser.sleep(3000)
  browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
  browser.actions().click().perform();
  }

  eveningEntry() {
    browser.ignoreSynchronization = true

    browser.sleep(3000)
    expect(browser.getTitle()).toEqual('HelloBetter');
    this.locator.eveningEntry.click();
    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    this.locator.sleepTime.clear();
    this.locator.sleepTime.sendKeys('10');
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    for (var i = 0; i < 3; i++) {
      this.locator.coffeeEntry.click();
    }
    browser.sleep(3000)
    for (var i = 0; i < 5; i++) {
      this.locator.teaEntry.click();
    }
    browser.sleep(3000)
    for (var i = 0; i < 2; i++) {
      this.locator.colaEntry.click();
    }

    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    this.locator.beerEntry.click();
    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 fuoaAn')).getWebElement()).perform();
    browser.actions().click().perform();
  }
  

}

module.exports = journalPage2;
