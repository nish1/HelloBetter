'use strict';
const { browser, element } = require('protractor');
const regLocator = require('../locators/regLocator.js');

class regPage {
  constructor() {
    this.locator = new regLocator();
    this.bedtime = browser.params.login.bedtime;
    this.EC = protractor.ExpectedConditions;
    this.timeOut = 60000;
  }

  regPortal() {
    browser.ignoreSynchronization = true
    browser.sleep(4000)
    browser.driver.actions().mouseMove(element(by.xpath('//*[@id="main"]/div/div[2]/form/div/div[4]/p/a')).getWebElement()).perform();
    browser.actions().click().perform();
    expect(browser.getTitle()).toEqual('HelloBetter');
    //this.locator.register.click();
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 czuyAY ChangeLanguage__ButtonLink-sc-18kdjhg-0 SwwaP')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.driver.actions().mouseMove(element(by.className('components__ListItemStyled-eczaep-1 hvPSzP')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(4000)
    this.locator.firstName.sendKeys('Test');
    this.locator.emailField.sendKeys('nishmithab3gs@gmail.com');
    this.locator.passwordField.sendKeys('Test@123');
    browser.sleep(4000)
    console.log("Selecting element by drop down", "OK");
    browser.driver.actions().mouseMove(element(by.xpath('//*[@id="main"]/div/div[2]/form/div/div[4]/select')).getWebElement()).perform();
    browser.sleep(6000)
    browser.actions().click().perform();
    var desiredOption = element.all(by.tagName('option')).get(2);
    var EC = protractor.ExpectedConditions;
    browser.wait(EC.visibilityOf(desiredOption), 5000);
    desiredOption.click();
    browser.sleep(4000)
    browser.driver.actions().mouseMove(element(by.className('components__Rect-vq0nuj-3 eSviAj')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(4000)
   // browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 czuyAY ChangeLanguage__ButtonLink-sc-18kdjhg-0 SwwaP')).getWebElement()).perform();
   // browser.actions().click().perform();
   
    browser.driver.actions().mouseMove(element(by.className('Button__Component-sc-1cra7sq-0 dqgmrB')).getWebElement()).perform();
    browser.actions().click().perform();

    





  }



}
module.exports = regPage;