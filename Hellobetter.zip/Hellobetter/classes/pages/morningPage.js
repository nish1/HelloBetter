'use strict';
const { browser } = require('protractor');
const morningPageLocator = require('../locators/morningPageLocator.js');

class morningPage {
  constructor() {
    this.locator = new morningPageLocator();
    this.EC = protractor.ExpectedConditions;
    this.timeOut = 60000;
  }

  morningPortal() {
    browser.ignoreSynchronization = true
    browser.sleep(5000)
    browser.driver.actions().mouseMove(element(by.className('Box__StyledBox-vxlplq-0 eamvjQ')).getWebElement()).perform();
    browser.actions().click().perform();
    //this.locator.entry19.click();
    expect(browser.getTitle()).toEqual(this.locator.morningEntryTitle);
    browser.sleep(2000);
    this.locator.saveEntry.click();
    browser.sleep(2000);
    browser.driver.actions().mouseMove(element(by.xpath('//*[@id="journal_entry_container_3"]/div/div[1]/div/p')).getWebElement()).perform();
    browser.actions().click().perform();
    expect(browser.getTitle()).toEqual('HelloBetter');
    this.locator.saveEntry.click();

  }
  //browser.executeScript('window.scrollTo(0,document.body.scrollHeight)').then(function(){
  //whatever you need to check for here
  // });

  eveningPortal() {
    browser.ignoreSynchronization = true
    browser.sleep(5000)
    browser.driver.actions().mouseMove(element(by.xpath('//*[@id="journal_entry_container_2"]/div/div[1]/div/p')).getWebElement()).perform();
    browser.actions().click().perform();
    expect(true).toBe(true);
    this.locator.saveEntry.click();

    browser.sleep(3000)
    browser.driver.actions().mouseMove(element(by.xpath('//*[@id="journal_entry_container_6"]/div/div[1]/div/p')).getWebElement()).perform();
    browser.actions().click().perform();
    browser.sleep(1000)
    this.locator.saveEntry.click();
  }
  logoutPortal() {
    browser.ignoreSynchronization = true
    browser.sleep(5000)
    expect(browser.getTitle()).toEqual('HelloBetter');
    console.log('Time spent in bed is displayed ');
    this.locator.leftEntry.click();
    this.locator.logout.click();
  }
}








module.exports = morningPage;