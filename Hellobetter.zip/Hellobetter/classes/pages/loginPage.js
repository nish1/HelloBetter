'use strict';
const { browser } = require('protractor');
const loginPageLocator = require('../locators/loginPageLocator.js');

class loginPage {
    constructor() {
        this.locator = new loginPageLocator();
        this.email = browser.params.login.email;
        this.passwd = browser.params.login.password;
        this.envUrl = browser.baseUrl;
        this.EC = protractor.ExpectedConditions;
        this.timeOut = 60000;
    }

    openPage() {
        browser.ignoreSynchronization = true;
        browser.get(this.envUrl);
        browser.sleep(4000)

        
        expect(browser.getTitle()).toEqual('HelloBetter');
        //this.locator.myAccount.click();
        //this.locator.login.click();
    }

    loginPortal() {
        browser.ignoreSynchronization = true;
        this.locator.emailField.sendKeys(this.email);
        this.locator.passwordField.sendKeys(this.passwd);
        this.locator.loginButton.click();
        expect(browser.getTitle()).toEqual('HelloBetter');
        browser.sleep(4000)


        

        
        //browser.actions().mouseMove(element(by.className('components__Path-vq0nuj-0 cSyhSj'))).perform()
        //browser.actions().click(element(by.css('.Add__RotatingIcon-v5uni3-0'))).perform()
        //this.locator.journalEntry.click();
        //browser.wait(this.EC.visibilityOf(this.locator.journalEntry), this.timeOut, 'login not successfull');
        //expect(browser.getTitle()).toEqual(this.locator.postLoginTitle);
    }


}

module.exports = loginPage;
