'use strict';

class protractorFixedConfig {

    setJasmineOptions() {
        return {
            //defaultTimeoutInterval: 4000000,
            showColors: true,
            isVerbose : true,
            includeStackTrace : true
        };
    }    
}

module.exports = protractorFixedConfig;