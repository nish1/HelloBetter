var protractorFixedConfig = require('../classes/config/protractorFixedConfig.js');
var protractorConfig = new protractorFixedConfig();
var Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
exports.config = {
    directConnect: true,

    baseUrl: 'https://patient-staging.hellobetter.de/journal',

    params: {
        login: {
            email: 'nishmithab3gs@gmail.com',
            password: 'Password@123',
            bedtime:'01:33',

        },
        //searchBy: {
        //    os: 'windows'
        //},
    },

    suites: {
        demoTest: '../tests/demotest.js',
    },

    capabilities: {
        'browserName': 'chrome',
      
    },

    framework: 'jasmine',

   // jasmineNodeOpts: protractorConfig.setJasmineOptions(),
    jasmineNodeOpts: {
        defaultTimeoutInterval: 10000
      },
    // Assign the test reporter to each running instance
  onPrepare:  async () => {
    await browser.waitForAngularEnabled(false);
  

    browser.driver.manage().window().maximize();

    jasmine.getEnv().addReporter(
      new Jasmine2HtmlReporter({
      savePath: 'target/html report'
    })
    );
},

};

